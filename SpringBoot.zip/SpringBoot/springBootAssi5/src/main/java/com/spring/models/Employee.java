package com.spring.models;

public class Employee {
	int id;
	String name;
	String location;
	String email_Id;
	String idname;
	
	public Employee() {
		
	}
	public Employee(String name, String location, String email_Id, String idname) {
		this.name 	  = name;
		this.location = location;
		this.email_Id = email_Id;
		this.idname	  = idname;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEmail_Id() {
		return email_Id;
	}
	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}
	public String getIdname() {
		return idname;
	}
	public void setIdname(String idname) {
		this.idname = idname;
	}
//	@Override
//	public String toString() {
//		// TODO Auto-generated method stub
//		String str = "{ name :"+ name +",\n";
//			   str+= "location :"+ location +",\n";
//			   str+= "email_Id :"+ email_Id +",\n";
//			   str+= "idname :"+ idname+" }";
//		return str;
//	}
}


package com.spring.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.spring.models.Employee;

@Component
public class EmployeeService {
	Map<String,Employee> empDetails = null;
	public Map<String,Employee> getAllEmployee() {
		empDetails = new HashMap<String,Employee>();
		empDetails.put("emp001", new Employee("Gaurav", "Bangalore", "gaurav.mane@wipro.com", "emp001"));
		empDetails.put("emp002", new Employee("Shubham", "Bangalore", "shubham.mane@hp.com", "emp002"));
		return empDetails;
	}
	
	public Employee searchEmployeeById(String idname) {
		Map<String, Employee> listEmployee = getAllEmployee();
		Employee employee = listEmployee.get(idname);
		System.out.println("-- "+listEmployee);
		return employee;
	}
	
	public Map<String,Employee> addEmployee(Employee employee) {
		Map<String, Employee> listEmployee = getAllEmployee();
		System.out.println("-->> "+employee.getIdname());
		listEmployee.put(employee.getIdname(), employee);
		return listEmployee;
	}
	
	public Map<String,Employee> deleteEmployee(String idname) {
		Map<String, Employee> listEmployee = getAllEmployee();
		listEmployee.remove(idname);
		return listEmployee;
	}
}

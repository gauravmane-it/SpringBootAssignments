package com.spring.springBoot;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.EmployeeService;
import com.spring.models.Employee;

@RestController
public class WelcomeController {
	@Autowired
	EmployeeService objEmployeeService;
	
	@RequestMapping(value="/addEmployee",method=RequestMethod.POST, consumes="application/json")
	public Map<String,Employee> addEmployee(@RequestBody Employee objEmployee) {
		Map<String,Employee> listEmployee = objEmployeeService.addEmployee(objEmployee);
		return listEmployee;
	}
	
	@RequestMapping(value="/updateEmployee",method=RequestMethod.PUT, consumes="application/json")
	public Map<String,Employee> updateEmployee(@RequestBody Employee objEmployee) {
		Map<String,Employee> listEmployee = objEmployeeService.addEmployee(objEmployee);
		return listEmployee;
	}
	
	@DeleteMapping(path="/deleteEmployee/{idname}", produces = "application/json")
	public Map<String,Employee> deleteEmployee(@PathVariable String idname) {
		Map<String,Employee> listEmployee = objEmployeeService.deleteEmployee(idname);
		return listEmployee;
	}

	@GetMapping(path="/display/{userid}", produces = "application/json")
	public Employee searchEmployeeById(@PathVariable String userid) {
		Employee listEmployee = objEmployeeService.searchEmployeeById(userid);
//		ModelAndView model = new ModelAndView();
//		model.addObject("status",listEmployee);
//		model.setViewName("data");
		return listEmployee;
	}
	
	@GetMapping(path = "/displayAll", produces = "application/json")
	public Map<String,Employee> searchEmployee() {
		Map<String,Employee> listEmployee = objEmployeeService.getAllEmployee();
		return listEmployee;
	}
}
package com.springBootAssi5.springBootAssi5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAssi5ApplicationTests {

	@Test
	void contextLoads() {
	}

}

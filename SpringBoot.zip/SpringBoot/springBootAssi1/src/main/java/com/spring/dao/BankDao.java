package com.spring.dao;

public class BankDao {
	public String getBankName() {
		return "SBI";
	}
}

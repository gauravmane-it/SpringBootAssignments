package com.spring.springBoot;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {
	
	@RequestMapping(value="/bankName",method=RequestMethod.GET)
	public String getBankName() {
		return "SBI";
	}
	
	@RequestMapping(value="/bankAddress",method=RequestMethod.GET)
	public String getBankAddress() {
		return "Bangalore";
	}
}
package com.spring.springBoot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.EmployeeService;
import com.spring.models.Employee;

@Controller
public class WelcomeController {
	@Autowired
	EmployeeService objEmployeeService;
	
	@RequestMapping("/")
	public String bankWithBranches() {
		return "index";
	}
	
	@PostMapping("/addEmployee")
	public ModelAndView addEmployee(Employee objEmployee) {
		String status = objEmployeeService.addEmployee(objEmployee);
		ModelAndView model = new ModelAndView();
		model.addObject("status",status);
		model.setViewName("index");
		return model;
	}
	
	@GetMapping("/display/{userid}")
	public ModelAndView searchEmployeeById(@PathVariable String userid) {
		List<Employee> listEmployee = objEmployeeService.searchEmployeeById(userid);
		ModelAndView model = new ModelAndView();
		model.addObject("status",listEmployee);
		model.setViewName("data");
		return model;
	}
	
	@GetMapping("/displayAll")
	public ModelAndView searchEmployee() {
		List<Employee> listEmployee = objEmployeeService.searchAllEmployee();
		ModelAndView model = new ModelAndView();
		model.addObject("status",listEmployee);
		model.setViewName("data");
		return model;
	}
}
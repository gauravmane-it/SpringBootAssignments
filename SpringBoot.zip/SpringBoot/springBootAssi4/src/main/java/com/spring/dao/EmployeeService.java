package com.spring.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.models.Employee;
import com.spring.models.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository objEmployeeRepository;
	
	public String addEmployee(Employee objEmployee) {
		String status = "Some problem occurred";
		
		Employee employee = objEmployeeRepository.save(objEmployee);
		status 			  = employee != null ? status="Epmloyee Added" : status;
		return status;
	}
	
	public List<Employee> searchEmployeeById(String idname) {
		List<Employee> listEmployee = objEmployeeRepository.findByIdname(idname);
		System.out.println("-- "+listEmployee);
		return listEmployee;
	}
	
	public List<Employee> searchAllEmployee() {
		System.out.println("-- ");
		List<Employee> listEmployee = objEmployeeRepository.findAll();
		System.out.println("-- "+listEmployee);
		return listEmployee;
	}
}
